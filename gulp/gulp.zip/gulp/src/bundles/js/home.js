function slider() {
    var src="hahaha";
    alert(config.hh);
}
var config={
    hh:"haha"
}