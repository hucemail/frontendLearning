var gulp = require('gulp');

//配置文件
var config = require("./gulp/config")();

// 自动刷新浏览器工具
var browserSync = require('browser-sync').create();

//顺序执行任务插件
var runSequence = require('run-sequence');

// 加载插件
var plugins = require("gulp-load-plugins")();

//获得所有任务列表，如：gulp/tasks/clean.js
var tasks = require("fs").readdirSync(config.tasks);

//加载任务
tasks.forEach(function (task) {
    require(config.tasks + task)(gulp, plugins, config, browserSync, runSequence);
});

//默认任务
gulp.task("default",["helper"]);

//帮助说明
gulp.task("helper", function () {
    console.log('*************************************************************');
    console.log('*                                                          *');
    console.log('*   gulp helper       帮助说明                             *');
    console.log('*   gulp serve        启动开发监控(将启动浏览器自动刷新)   *');
    console.log('*   gulp build        编译(不会启动浏览器刷新)             *');
    console.log('*   gulp publish      打包（需要先执行编译才能进行打包）   *');
    console.log('*   gulp release      发布（编译打包一体操作）             *');
    console.log('*************************************************************');
});

//启动任务
gulp.task("serve", function () {
    runSequence("clean:build", "reload", "watch");
});
//编译
gulp.task("build", function () {
    runSequence("clean:build", 'html:build',"image:build", "js:build", "css:build", "compass:build","plugins:build","resources:build");
});
//打包
gulp.task("publish", function () {
    return gulp.src(config.build + "**/*")
        .pipe(plugins.zip('publish.zip'))
        .pipe(gulp.dest(config.release));
});
//发布
gulp.task("release",function () {
    runSequence("clean:build", 'html:build', "image:build", "js:build", "css:build", "compass:build","plugins:build","resources:build","publish");
});