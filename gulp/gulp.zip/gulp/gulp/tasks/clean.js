var del=require("del");
module.exports=function (gulp,plugins,config,browserSync,runSequence) {
    gulp.task("clean:build",function (cb) {
        return del(config.build+"*",cb);
    });
};
