module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("scss:build", function () {
        return gulp.src(config.paths.scss)
            .pipe(plugins.sass({outputStyle: 'compressed'}).on("error",plugins.sass.logError))
            .pipe(gulp.dest(config.paths.destscss))
            .pipe(browserSync.stream());
    });
};
