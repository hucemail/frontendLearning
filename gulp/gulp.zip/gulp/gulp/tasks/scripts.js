module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("js:build", function () {
        return gulp.src(config.paths.js)
            .pipe(plugins.uglify({
                mangle: true,  //类型：Boolean 默认：true 是否修改变量名
                compress: true //类型：Boolean 默认：true 是否完全压缩
            }))
            .pipe(gulp.dest(config.paths.destjs))
            .pipe(browserSync.stream());
    });
};


