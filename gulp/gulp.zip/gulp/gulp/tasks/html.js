module.exports=function (gulp,plugins,config,browserSync,runSequence) {
    gulp.task("html:build",function () {
        return gulp.src(config.paths.htmls)
            .pipe(plugins.ejs())
            .pipe(plugins.htmlmin({
               // collapseWhitespace: true,            //压缩html
                //collapseBooleanAttributes: true,     //省略布尔属性的值
                removeComments: true,                //清除html注释
               // removeEmptyAttributes: true,         //删除所有空格作为属性值
                removeScriptTypeAttributes: true,    //删除type=text/javascript
                removeStyleLinkTypeAttributes: true, //删除type=text/css
                minifyJS:true,                       //压缩页面js
                minifyCSS:true                       //压缩页面css
            }))
            .pipe(gulp.dest(config.paths.desthtmls))
            .pipe(browserSync.stream());
    });
};
