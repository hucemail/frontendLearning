module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("watch", function () {
        //启动一组任务
        gulp.start('html:build',"image:build","js:build","css:build","scss:build","plugins:build","resources:build");

        gulp.watch(config.paths.htmls,['html:build']);  //监听html，并将其交给名为html:build的任务进行处理

        gulp.watch(config.paths.images,['image:build']);

        gulp.watch(config.paths.js,['js:build']);

        gulp.watch(config.paths.css,['css:build']);

        gulp.watch(config.paths.scss,['scss:build']);

        gulp.watch(config.paths.plugins,['plugins:build']);

        gulp.watch(config.paths.plugins,['resources:build']);

        //dist目录下的任何html发生改变时(包括子目录)自动刷新
        gulp.watch(config.paths.buildhtmls).on("change", browserSync.reload);
    });
};
