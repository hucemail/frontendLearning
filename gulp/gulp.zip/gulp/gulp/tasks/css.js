module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("css:build", function () {
        return gulp.src(config.paths.css)
            .pipe(plugins.cssnano())
            .pipe(gulp.dest(config.paths.destcss))
            .pipe(browserSync.stream());
    });
};


