module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("compass:build", function () {
        return gulp.src(config.paths.scss)
            .pipe(plugins.compass({
                css: config.paths.destscss, //compass輸出位置
                sass:config.paths.compass, //sass來源路徑
                style: 'compressed', //CSS壓縮格式，預設(nested)
                comments: false //是否要註解，預設(true)
            }))
            .pipe(gulp.dest(config.paths.destscss))
            .pipe(browserSync.stream());
    });
};
