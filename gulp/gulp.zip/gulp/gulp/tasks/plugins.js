module.exports=function (gulp,plugins,config,browserSync,runSequence) {
    gulp.task("plugins:build",function () {
        return gulp.src(config.paths.plugins)
            .pipe(gulp.dest(config.paths.destplugins))
            .pipe(browserSync.stream());
    });
};

