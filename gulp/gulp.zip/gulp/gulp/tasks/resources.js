module.exports=function (gulp,plugins,config,browserSync,runSequence) {
    gulp.task("resources:build",function () {
        return gulp.src(config.paths.resources)
            .pipe(gulp.dest(config.paths.destresources))
            .pipe(browserSync.stream());
    });
};

