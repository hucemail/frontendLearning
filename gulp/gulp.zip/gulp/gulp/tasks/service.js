var  ssi=require("browsersync-ssi");
module.exports = function (gulp, plugins, config, browserSync, runSequence) {
    gulp.task("reload", function () {
        browserSync.init({
            port: config.port,
            server: {
                baseDir: "./"+config.build,
                middleware: ssi({
                    baseDir: "./"+config.build,
                    ext: '.shtml'
                })
            }
        });
    });
};
