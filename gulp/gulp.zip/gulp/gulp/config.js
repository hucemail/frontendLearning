module.exports = function () {
    var confilg = {
        src: "src/",                        //源代码目录
        tasks: "./gulp/tasks/",              //任务目录
        port: 2017,                        //端口号
        build: "build/",                   //编译目录
        release: "release/",                //发布目录
        paths:{
            htmls:['src/**/*.html',"!src/bundles/**/*.html"],      //监听src下所有html文件，排除src/bundles目录下的html
            desthtmls:"build/",                                  //当监听到src下的html文件有变动后，会经过相应的任务处理后自动更新到build目录
            buildhtmls:'build/**/*.html',                         //build目录下的html文件有改变会自动刷新浏览器
            images:"src/bundles/images/**/*.{jpg,png,jpeg,gif,ico}",//监听src/bundles/images下的图片文件
            destimages:"build/bundles/images",                    //监听到图片文件有变动，会进行相应的任务处理自动更新到build/bundles/images目录
            js:"src/bundles/js/**/*.js",
            destjs:"build/bundles/js",
            css:"src/bundles/css/**/*.css",
            destcss:"build/bundles/css",
            scss:"src/bundles/scss/**/*.scss",
            destscss:"build/bundles/css",
            plugins:"src/bundles/plugins/**/*.*",
            destplugins:"build/bundles/plugins",
            resources:"src/bundles/resources/**/*.*",
            destresources:"build/bundles/resources",
        }
    };
    return confilg;
};
